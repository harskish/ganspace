import triangle.core1 as c1
import triangle.core as c

T = c1.TriangulateIO
while True:
    out = c.new_data(1000)
